from flask import Flask,jsonify,render_template,request
from flask_pymongo import PyMongo
from bson import ObjectId
import pymongo
from pymongo import MongoClient

app = Flask(__name__)
app.config['MONGO_URI'] = 'mongodb://localhost:27017/taskdb'
app.config['MONGO_DBNAME'] = 'user'
mongo = PyMongo(app)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/users', methods=['POST'])
def create_user():
    data = request.form
    user = {
        '_id': request.json['_id'],
        'name': request.json['name'],
        'email': request.json['email'],
        'password': request.json['password']
    }
    result = mongo.db.user.insert_one(user)
    return jsonify(str(result.inserted_id)), 201

@app.route('/users', methods=['GET'])
def read_users():
    users = []
    for user in mongo.db.users.find():
        users.append({
            '_id': str(user['_id']),
            'name': user['name'],
            'email': user['email'],
            'password':user['password']
        })
    return jsonify(users), 200

@app.route('/users/<id>', methods=['GET'])
def read_user(id):
    user = mongo.db.users.find_one({'_id': ObjectId(id)})
    if user:
        return jsonify({
            '_id': str(user['_id']),
            'name': user['name'],
            'email': user['email']
        }), 200
    else:
        return jsonify({'error': 'User not found'}), 404

@app.route('/users/<id>', methods=['PUT'])
def update_user(id):
    result = mongo.db.users.update_one(
        {'_id': ObjectId(id)},
        {'$set': {
            'name': request.json['name'],
            'email': request.json['email']
        }}
    )
    if result.modified_count == 1:
        return jsonify({'message': 'User updated'}), 200
    else:
        return jsonify({'error': 'User not found'}), 404

@app.route('/users/<id>', methods=['DELETE'])
def delete_user(id):
    result = mongo.db.user.delete_one({'_id': ObjectId(id)})
    if result.deleted_count == 1:
        return jsonify({'message': 'User deleted'}), 200
    else:
        return jsonify({'error': 'User not found'}), 404


if __name__ =='__main__':
    app.run(debug=True)
